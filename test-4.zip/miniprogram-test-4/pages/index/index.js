//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    motto: 'Hello World',
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    imgUrls: [
      '../../img/shanzha.jpg',
      '../../img/shejian.jpg',
      '../../img/snack.jpg'
    ],
    indicatorDots: true,
    autoplay: true,
    interval: 5000,
    duration: 1000
  },
  
  //事件处理函数
  bindViewTap: function () {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onLoad: function () {
    var that = this;
    // 查看授权
    wx.getSetting({
      success: (res) => {
        console.log(res)
        if (res.authSetting['scope.userInfo']) {
          wx.getUserInfo({
            success: (res) => {
              // 已授权
              wx.login({
                success: (res) => {
                  console.log(res)
                }
              })
            }
          })
        } else {
          // 未授权 显示授权界面
          that.setData({
            hasUserInfo: true,
          })
        }
      }
    })
  },
  bindGetUserInfo(e) {
    console.log(e);
    console.log(this);
    // var that = this;
    if (e.detail.userInfo) {
      // 用户允许授权
      console.log("用户的信息：");
      console.log(e.detail.userInfo);
      this.setData({
        //隐藏授权界面
        hasUserInfo: false
      });
    } else {
      // 用户拒绝了授权
      wx.showModal({
        title: 'Warning!',
        content: '您点击了拒绝授权，将无法进入小程序，请授权之后再进入!!!',
        showCancel: false,
        confirmText: '返回授权',
        success: (res) => {
          // 用户没有授权成功 
          console.log('用户点击了返回授权时返回的信息：')
          console.log(res)
          if (res.confirm) {
            console.log('此时用户点击了"返回授权！"')
          }
        }
      })
    }
  },
  getUserInfo: function (e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  }
})
